package br.com.linkedin.people_graph_service.people_graph_service.controller;


import br.com.linkedin.people_graph_service.people_graph_service.service.UserService;
import org.springframework.web.bind.annotation.*;
// Importa a classe List para retornar listas de IDs
import java.util.List;

// Indica que esta classe é um controller REST do Spring
@RestController

// Define a URL base para todas as rotas deste controller
@RequestMapping("/grafo/users")
public class UserController {

    // Injeção do serviço que contém a lógica de negócio
    private final UserService userService;

    // Construtor do controller que recebe o UserService via injeção de dependência
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Endpoint POST para conectar dois usuários
    // Exemplo de chamada: POST /grafo/users/1/connect/2
    @PostMapping("/{IdUsuario}/connect/{IdAmigo}")
    public void connect(@PathVariable Long userId, @PathVariable Long friendId) {
        userService.connectUsers(userId, friendId);
    }

    // Endpoint POST para criar um novo usuário
    // O objeto User deve vir no corpo da requisição em formato JSON
    // Exemplo de corpo JSON:
    // {
    //     "id": 1,
    //     "name": "Vinicius"
    // }
    @PostMapping
    public void createUser(@RequestBody br.com.linkedin.people_graph_service.people_graph_service.entity.User user) {
        userService.createUser(user);
    }

    // Endpoint GET para listar os IDs dos amigos de um usuário
    // Exemplo: GET /grafo/users/1/friends
    @GetMapping("/{IdUsuario}/friends")
    public List<Long> getFriends(@PathVariable Long userId) {
        return userService.getFriendsIds(userId);
    }

    // Endpoint GET para calcular o grau de conexão entre dois usuários
    // Exemplo: GET /grafo/users/1/degree/4
    @GetMapping("/{IdUsuario}/degree/{IdOutroUsuario}")
    public Integer getDegree(@PathVariable Long userId, @PathVariable Long otherUserId) {
        return userService.getDegree(userId, otherUserId);
    }
}
