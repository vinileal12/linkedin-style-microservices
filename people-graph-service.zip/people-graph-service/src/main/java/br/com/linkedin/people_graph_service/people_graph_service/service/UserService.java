package br.com.linkedin.people_graph_service.people_graph_service.service;

import br.com.linkedin.people_graph_service.people_graph_service.entity.User;
import br.com.linkedin.people_graph_service.people_graph_service.repository.UserRepository;

import java.util.*;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {

    private final UserRepository repository;

    public UserService(UserRepository repository) {
        this.repository = repository;
    }
    @Transactional
    public void connectUsers(Long userId, Long friendId) {
        User user = repository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User não encontrado"));
        User friend = repository.findById(friendId)
                .orElseThrow(() -> new RuntimeException("Amigo não encontrado"));

        if (!user.getConnections().contains(friend)) {
            user.getConnections().add(friend);
        }

        repository.save(user);
    }


    public List<Long> getFriendsIds(Long userId) {
        User user = repository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User não encontrado"));

        return user.getConnections().stream()
                .map(User::getId)
                .collect(Collectors.toList());
    }


    @Transactional
    public void createUser(User user) {
        if (!repository.existsById(user.getId())) {
            repository.save(user);
        }
    }


    public Integer getDegree(Long userId, Long otherUserId) {
        User user = repository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado no grafo"));
        User other = repository.findById(otherUserId)
                .orElseThrow(() -> new RuntimeException("Outro usuário não encontrado no grafo"));


        Queue<User> queue = new LinkedList<>();
        Map<Long, Integer> visited = new HashMap<>();
        queue.add(user);
        visited.put(user.getId(), 0);

        while (!queue.isEmpty()) {
            User current = queue.poll();
            int depth = visited.get(current.getId());

            if (current.getId().equals(other.getId())) {
                return depth; // Grau encontrado
            }

            for (User friend : current.getConnections()) {
                if (!visited.containsKey(friend.getId())) {
                    visited.put(friend.getId(), depth + 1);
                    queue.add(friend);
                }
            }
        }

        return null; // Não existe caminho (não conectado)
    }



}
