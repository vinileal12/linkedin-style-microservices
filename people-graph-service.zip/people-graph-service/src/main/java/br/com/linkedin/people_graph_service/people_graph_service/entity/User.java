package br.com.linkedin.people_graph_service.people_graph_service.entity;


import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;
import org.springframework.data.neo4j.core.schema.Relationship;

import java.util.HashSet;
import java.util.Set;

@Entity
@Node("User")
@Data
@AllArgsConstructor@NoArgsConstructor
public class User {
    @Id
    private Long id;
    private String firstName;
    private String lastName;
    private String email;

    @Relationship(type = "CONNECTED", direction = Relationship.Direction.OUTGOING)
    private Set<User> connections = new HashSet<>();

    public Set<User>getConnections() {
        if (connections == null) connections = new HashSet<>();
        return connections;
    }
}
