package br.com.linkedin.people_graph_service.people_graph_service.repository;

import br.com.linkedin.people_graph_service.people_graph_service.entity.User;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface UserRepository extends Neo4jRepository<User, Long> {
}
