package br.com.linkedin.people_graph_service.people_graph_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeopleGraphServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
