package br.com.linkedinfake.core_service.service;


import br.com.linkedinfake.core_service.DTOs.comment.CommentCreateDTO;
import br.com.linkedinfake.core_service.DTOs.comment.CommentDTO;
import br.com.linkedinfake.core_service.model.Comment;
import br.com.linkedinfake.core_service.model.Post;
import br.com.linkedinfake.core_service.model.User;
import br.com.linkedinfake.core_service.repository.CommentRepository;
import br.com.linkedinfake.core_service.repository.PostRepository;
import br.com.linkedinfake.core_service.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CommentService {
	 private final CommentRepository commentRepository;
	    private final UserRepository userRepository;
	    private final PostRepository postRepository;

	    public CommentService(CommentRepository commentRepository, UserRepository userRepository, PostRepository postRepository) {
	        this.commentRepository = commentRepository;
	        this.userRepository = userRepository;
	        this.postRepository = postRepository;
	    }

	    // Criar comentário
	    public CommentDTO createComment(Long postId, CommentCreateDTO dto, Long userId) {
	        User author = userRepository.findById(userId)
	                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

	        Post post = postRepository.findById(postId)
	                .orElseThrow(() -> new RuntimeException("Post não encontrado"));

	        Comment comment = new Comment();
	        comment.setAuthor(author);
	        comment.setPost(post);
	        comment.setContent(dto.getContent());

	        Comment saved = commentRepository.save(comment);

	        return toDTO(saved);
	    }

	    // Buscar todos os comentários de um post
	    public List<CommentDTO> getCommentsByPost(Long postId) {
	        List<Comment> comments = commentRepository.findByPostIdOrderByCreatedAtAsc(postId);
	        return comments.stream().map(this::toDTO).collect(Collectors.toList());
	    }

	    // Converter Comment para CommentDTO
	    private CommentDTO toDTO(Comment comment) {
	        CommentDTO dto = new CommentDTO();
	        dto.setId(comment.getId());
	        dto.setContent(comment.getContent());
	        dto.setAuthorName(comment.getAuthor().getFirstName() + " " + comment.getAuthor().getLastName());
	        dto.setCreatedAt(comment.getCreatedAt().format(DateTimeFormatter.ISO_DATE_TIME));
	        return dto;
	    }
}
