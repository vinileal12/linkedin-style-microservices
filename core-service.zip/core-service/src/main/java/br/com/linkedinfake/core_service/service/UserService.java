package br.com.linkedinfake.core_service.service;


import br.com.linkedinfake.core_service.DTOs.user.UserDTO;
import br.com.linkedinfake.core_service.DTOs.user.UserProfileDTO;
import br.com.linkedinfake.core_service.model.Skill;
import br.com.linkedinfake.core_service.model.User;
import br.com.linkedinfake.core_service.repository.ConnectionRepository;
import br.com.linkedinfake.core_service.repository.SkillRepository;
import br.com.linkedinfake.core_service.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final ConnectionRepository connectionRepository;
    private final RestTemplate restTemplate;
    private final String neo4jBaseUrl = "http://localhost:8082/graph/users"; // URL do microserviço Neo4j
    private final SkillRepository skillRepository;

    public UserService(UserRepository userRepository, ConnectionRepository connectionRepository, SkillRepository skillRepository) {
        this.userRepository = userRepository;
        this.connectionRepository = connectionRepository;
        this.restTemplate = new RestTemplate();
        this.skillRepository = skillRepository;
    }

    public Optional<UserDTO> findById(Long id) {
        return userRepository.findById(id).map(this::toResponse);
    }

    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    // Salva usuário no banco principal e também cria no Neo4j
    public User save(User user) {
        User savedUser = userRepository.save(user);

        try {
            // Converte para DTO compatível com o Neo4j
            GraphUserDTO graphUser = new GraphUserDTO(
                    savedUser.getId(),
                    savedUser.getFirstName(),
                    savedUser.getLastName()
            );

            restTemplate.postForObject(neo4jBaseUrl, graphUser, Void.class);
        } catch (Exception e) {
            System.err.println("Erro ao criar usuário no Neo4j: " + e.getMessage());
        }

        return savedUser;
    }

    public List<UserDTO> findAvailableConnections(Long userId) {
        List<User> allUsers = userRepository.findAll();

        // conexões existentes do usuário
        List<Long> connectedIds = connectionRepository.findByUserId(userId)
                .stream()
                .map(c -> c.getFriend().getId())
                .collect(Collectors.toList());

        return allUsers.stream()
                .filter(u -> !u.getId().equals(userId)) // remove ele mesmo
                .filter(u -> !connectedIds.contains(u.getId())) // remove quem já está conectado
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    public UserDTO toResponse(User user) {
        UserDTO dto = new UserDTO();
        dto.setId(user.getId());
        dto.setFirstName(user.getFirstName());
        dto.setLastName(user.getLastName());
        dto.setEmail(user.getEmail());
        return dto;
    }

    // DTO simples para enviar ao Neo4j
    public static class GraphUserDTO {
        private Long id;
        private String firstName;
        private String lastName;

        public GraphUserDTO(Long id, String firstName, String lastName) {
            this.id = id;
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public Long getId() { return id; }
        public String getFirstName() { return firstName; }
        public String getLastName() { return lastName; }

        public void setId(Long id) { this.id = id; }
        public void setFirstName(String firstName) { this.firstName = firstName; }
        public void setLastName(String lastName) { this.lastName = lastName; }
    }


    public User saveUser(User user) {
        return userRepository.save(user);
    }

    public UserProfileDTO toProfileResponse(User user) {
        UserProfileDTO dto = new UserProfileDTO();
        dto.setId(user.getId());
        dto.setFirstName(user.getFirstName());
        dto.setLastName(user.getLastName());
        dto.setEmail(user.getEmail());
        dto.setDescription(user.getDescription());
        dto.setSkills(
                user.getSkills().stream()
                        .map(Skill::getSkillName)
                        .collect(Collectors.toList())
        );
        return dto;
    }

    public Optional<User> getUserWithSkills(Long id) {
        return userRepository.findByIdWithSkills(id);
    }

    public Skill addSkill(Long userId, String skillName) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        Skill skill = new Skill();
        skill.setSkillName(skillName);
        skill.setUser(user);
        return skillRepository.save(skill);
    }

    public void deleteSkill(Long skillId) {
        skillRepository.deleteById(skillId);
    }
}