package br.com.linkedinfake.core_service.DTOs.message;

import lombok.Data;

@Data
public class MessageCreateDTO {
	private Long senderId;
    private Long receiverId;
    private String body;
}
