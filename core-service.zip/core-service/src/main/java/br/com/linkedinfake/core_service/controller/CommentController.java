package br.com.linkedinfake.core_service.controller;

// Importações necessárias
import br.com.linkedinfake.core_service.DTOs.comment.CommentCreateDTO;
import br.com.linkedinfake.core_service.DTOs.comment.CommentDTO;
import br.com.linkedinfake.core_service.DTOs.user.UserPrincipalDTO;
import br.com.linkedinfake.core_service.service.CommentService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/posts/{postId}/comments") // Define rota base relacionada aos comentários de um post
public class CommentController {

    private final CommentService commentService;

    // Injeta o CommentService via construtor
    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    // Endpoint para criar um comentário em um post
    @PostMapping
    public ResponseEntity<CommentDTO> createComment(
            @PathVariable Long postId,            // ID do post alvo
            @RequestBody CommentCreateDTO dto     // Dados do comentário
    ) {
        // Recupera o usuário autenticado do contexto de segurança
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        Long userId;
        // Verifica se o usuário está autenticado e extrai o ID
        if (principal instanceof UserPrincipalDTO user) {
            userId = user.getId(); // Pega o ID do usuário logado
        } else {
            throw new RuntimeException("Usuário não autenticado");
        }

        // Cria o comentário e retorna como resposta
        return ResponseEntity.ok(commentService.createComment(postId, dto, userId));
    }

    // Endpoint para listar os comentários de um post
    @GetMapping
    public ResponseEntity<List<CommentDTO>> getComments(@PathVariable Long postId) {
        return ResponseEntity.ok(commentService.getCommentsByPost(postId));
    }
}
