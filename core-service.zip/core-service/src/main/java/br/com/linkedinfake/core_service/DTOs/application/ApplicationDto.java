package br.com.linkedinfake.core_service.DTOs.application;

import lombok.Data;

@Data
public class ApplicationDto {
	private Long id;
    private Long userId;
    private Long jobId;
    private String appliedAt;

    public ApplicationDto(Long id, Long userId, Long jobId, String appliedAt) {
        this.id = id;
        this.userId = userId;
        this.jobId = jobId;
        this.appliedAt = appliedAt;
    }
}
