package br.com.linkedinfake.core_service.DTOs.user;

import lombok.Data;

import java.util.List;

@Data
public class UserProfileDTO {
	private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String description;
    private List<String> skills;
}
