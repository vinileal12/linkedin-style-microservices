package br.com.linkedinfake.core_service.auth;

// Importações necessárias para o funcionamento do controller
import br.com.linkedinfake.core_service.jwtUtil.JwtUtil;
import br.com.linkedinfake.core_service.login.LoginRequest;
import br.com.linkedinfake.core_service.login.LoginResponse;
import br.com.linkedinfake.core_service.model.User;
import br.com.linkedinfake.core_service.service.UserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// Define que essa classe é um controlador REST e responde por requisições com caminho "/auth"
@RestController
@RequestMapping("/auth")
public class AuthController {

	private final UserService userService;
	private final PasswordEncoder passwordEncoder;

	// Injeta as dependências via construtor
	public AuthController(UserService userService, PasswordEncoder passwordEncoder) {
		this.userService = userService;
		this.passwordEncoder = passwordEncoder;
	}

	// Endpoint para login: recebe email e senha, retorna token JWT
	@PostMapping("/login")
	public LoginResponse login(@RequestBody LoginRequest request) {
		// Busca o usuário pelo e-mail informado
		User user = userService.findByEmail(request.getEmail())
				.orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

		// Verifica se a senha informada está correta
		if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
			throw new RuntimeException("Senha incorreta");
		}

		// Gera token JWT com base no ID do usuário
		String token = JwtUtil.generateToken(user.getId());

		// Monta a resposta com os dados do usuário e o token
		LoginResponse response = new LoginResponse();
		response.setUserId(user.getId());
		response.setEmail(user.getEmail());
		response.setAccessToken(token);
		return response;
	}
}
