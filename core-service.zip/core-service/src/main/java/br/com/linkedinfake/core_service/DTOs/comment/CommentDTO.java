package br.com.linkedinfake.core_service.DTOs.comment;

import lombok.Data;

@Data
public class CommentDTO {
	   private Long id;
	    private Long authorId;
	    private String authorName;
	    private String content;
	    private String createdAt;
}
