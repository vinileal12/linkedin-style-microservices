package br.com.linkedinfake.core_service.DTOs.user;

import lombok.Data;

@Data
public class UserRegisterDTO {
	 private String firstName;
	    private String lastName;
	    private String email;
	    private String password; // senha simples vinda do front
}
