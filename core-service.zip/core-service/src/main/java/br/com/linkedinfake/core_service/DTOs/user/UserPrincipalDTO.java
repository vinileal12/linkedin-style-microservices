package br.com.linkedinfake.core_service.DTOs.user;

import br.com.linkedinfake.core_service.model.User;
import lombok.Data;

@Data
public class UserPrincipalDTO {
	private Long id;
    private String firstName;
    private String lastName;
    private String email;

    public UserPrincipalDTO(User user) {
        this.id = user.getId();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.email = user.getEmail();
    }
}
