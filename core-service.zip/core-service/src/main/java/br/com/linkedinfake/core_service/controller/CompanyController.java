package br.com.linkedinfake.core_service.controller;

// Importações necessárias
import br.com.linkedinfake.core_service.DTOs.company.CompanyCreateDTO;
import br.com.linkedinfake.core_service.DTOs.company.CompanyDTO;
import br.com.linkedinfake.core_service.DTOs.job.JobCreateDto;
import br.com.linkedinfake.core_service.DTOs.job.JobDto;
import br.com.linkedinfake.core_service.service.CompanyService;
import br.com.linkedinfake.core_service.service.JobService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/companies") // Define a rota base para as empresas
public class CompanyController {

    private final JobService jobService;
    private final CompanyService companyService;

    // Injeta os serviços via construtor
    public CompanyController(JobService jobService, CompanyService companyService) {
        this.jobService = jobService;
        this.companyService = companyService;
    }

    // ==== Endpoints relacionados à Company ====

    // Cria uma nova empresa
    @PostMapping
    public ResponseEntity<CompanyDTO> create(@RequestBody CompanyCreateDTO dto) {
        return ResponseEntity.ok(companyService.createCompany(dto));
    }

    // Busca uma empresa pelo ID
    @GetMapping("/{id}")
    public ResponseEntity<CompanyDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(companyService.getCompanyById(id));
    }

    // Lista todas as empresas
    @GetMapping
    public ResponseEntity<List<CompanyDTO>> getAll() {
        return ResponseEntity.ok(companyService.getAllCompanies());
    }

    // ==== Endpoints relacionados a Jobs da Company ====

    // Lista todas as vagas (jobs) de uma empresa específica
    @GetMapping("/{id}/jobs")
    public List<JobDto> getJobsByCompany(@PathVariable Long id) {
        return jobService.findByCompanyId(id);
    }

    // Cria uma nova vaga (job) para uma empresa específica
    @PostMapping("/{id}/jobs")
    public ResponseEntity<JobDto> createJob(@PathVariable Long id, @RequestBody JobCreateDto dto) {
        return ResponseEntity.ok(jobService.createJob(id, dto));
    }
}
