package br.com.linkedinfake.core_service.service;


import br.com.linkedinfake.core_service.DTOs.post.PostRequestDto;
import br.com.linkedinfake.core_service.DTOs.post.PostResponseDto;
import br.com.linkedinfake.core_service.GraphIntegrationService.GraphIntegrationService;
import br.com.linkedinfake.core_service.model.Post;
import br.com.linkedinfake.core_service.model.User;
import br.com.linkedinfake.core_service.repository.PostRepository;
import br.com.linkedinfake.core_service.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PostService {
	private final PostRepository postRepository;
	private final UserRepository userRepository;
	private final CommentService commentService;
	private final GraphIntegrationService graphIntegrationService;

	public PostService(PostRepository postRepository, UserRepository userRepository,
					   CommentService commentService, GraphIntegrationService graphIntegrationService) {
		this.postRepository = postRepository;
		this.userRepository = userRepository;
		this.commentService = commentService;
		this.graphIntegrationService = graphIntegrationService;
	}

	// Cria um post para o usuário logado
	public PostResponseDto createPost(PostRequestDto request, Long userId) {
		User author = userRepository.findById(userId)
				.orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

		Post post = new Post();
		post.setAuthor(author);
		post.setContent(request.getContent());

		Post saved = postRepository.save(post);
		return toResponse(saved, userId); // passa currentUserId
	}

	// Lista posts de um usuário específico
	public List<PostResponseDto> getPostsByUserId(Long userId) {
		return postRepository.findByAuthorId(userId)
				.stream()
				.map(post -> toResponse(post, userId)) // passa currentUserId
				.collect(Collectors.toList());
	}

	// Lista posts de uma lista de usuários (ex.: feed do usuário com posts de amigos)
	public List<PostResponseDto> getPostsByUserIds(List<Long> userIds, Long currentUserId) {
		List<Post> posts = postRepository.findAllByAuthorIdInOrderByCreatedAtDesc(userIds);
		return posts.stream()
				.map(post -> toResponse(post, currentUserId)) // passa currentUserId
				.collect(Collectors.toList());
	}

	// Converte Post para PostResponseDto, incluindo comentários e grau de amizade
	private PostResponseDto toResponse(Post post, Long currentUserId) {
		PostResponseDto dto = new PostResponseDto();
		dto.setId(post.getId());
		dto.setContent(post.getContent());
		dto.setAuthorName(post.getAuthor().getFirstName() + " " + post.getAuthor().getLastName());
		dto.setCreatedAt(post.getCreatedAt().format(DateTimeFormatter.ISO_DATE_TIME));
		dto.setComments(commentService.getCommentsByPost(post.getId())); // garante lista de comentários
		dto.setDegree(graphIntegrationService.getFriendDegree(currentUserId, post.getAuthor().getId())); // calcula grau
		return dto;
	}


}

