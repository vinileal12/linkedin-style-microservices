package br.com.linkedinfake.core_service.repository;


import br.com.linkedinfake.core_service.model.Post;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PostRepository extends JpaRepository<Post, Long> {
	List<Post> findByAuthorId(Long authorId);
	List<Post> findAllByAuthorIdInOrderByCreatedAtDesc(List<Long> userIds);
}
