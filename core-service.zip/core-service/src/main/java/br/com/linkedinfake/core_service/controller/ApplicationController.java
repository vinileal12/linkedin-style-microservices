package br.com.linkedinfake.core_service.controller;

// Importações necessárias
import br.com.linkedinfake.core_service.DTOs.application.ApplicationDto;
import br.com.linkedinfake.core_service.service.ApplicationService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/jobs") // Define a rota base para esse controller
public class ApplicationController {

    private final ApplicationService applicationService;

    // Injeta o ApplicationService via construtor
    public ApplicationController(ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    // Endpoint para um usuário se candidatar a uma vaga (job)
    // Ex: POST /jobs/5/apply?userId=10
    @PostMapping("/{jobId}/apply")
    public ApplicationDto applyToJob(@PathVariable Long jobId, @RequestParam Long userId) {
        // Chama o serviço de aplicação para processar a candidatura
        return applicationService.apply(userId, jobId);
    }
}
