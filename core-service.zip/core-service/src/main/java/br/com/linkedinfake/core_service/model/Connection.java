package br.com.linkedinfake.core_service.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Connection {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    // Usuário que faz a conexão
	    @ManyToOne
	    @JoinColumn(name = "user_id", nullable = false)
	    private User user;

	    // Amigo/conectado
	    @ManyToOne
	    @JoinColumn(name = "friend_id", nullable = false)
	    private User friend;
}
