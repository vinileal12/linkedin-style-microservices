package br.com.linkedinfake.core_service.controller;

// Importações necessárias
import br.com.linkedinfake.core_service.DTOs.user.UserPrincipalDTO;
import br.com.linkedinfake.core_service.GraphIntegrationService.GraphIntegrationService;
import br.com.linkedinfake.core_service.model.Connection;
import br.com.linkedinfake.core_service.model.User;
import br.com.linkedinfake.core_service.repository.ConnectionRepository;
import br.com.linkedinfake.core_service.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/connections") // Define a rota base para conexões entre usuários
public class ConnectionController {

    private final GraphIntegrationService graphService;
    private final ConnectionRepository connectionRepository;
    private final UserRepository userRepository;

    // Injeta as dependências via construtor
    public ConnectionController(GraphIntegrationService graphService, ConnectionRepository connectionRepository,
                                UserRepository userRepository) {
        this.graphService = graphService;
        this.connectionRepository = connectionRepository;
        this.userRepository = userRepository;
    }

    // Endpoint para conectar o usuário logado a outro usuário (friendId)
    @PostMapping("/{friendId}")
    public void connect(@PathVariable Long friendId) {
        // Recupera o usuário autenticado do contexto de segurança
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        UserPrincipalDTO principal = (UserPrincipalDTO) auth.getPrincipal();
        Long userId = principal.getId();

        // Cria conexão no banco de grafos (Neo4j)
        graphService.createConnection(userId, friendId);

        // Busca os dois usuários no banco relacional
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        User friend = userRepository.findById(friendId)
                .orElseThrow(() -> new RuntimeException("Amigo não encontrado"));

        // Cria e salva a conexão no banco relacional
        Connection connection = new Connection();
        connection.setUser(user);
        connection.setFriend(friend);
        connectionRepository.save(connection);
    }
}
