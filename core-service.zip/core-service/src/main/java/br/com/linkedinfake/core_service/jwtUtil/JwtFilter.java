package br.com.linkedinfake.core_service.jwtUtil;

import br.com.linkedinfake.core_service.DTOs.user.UserPrincipalDTO;
import br.com.linkedinfake.core_service.model.User;
import br.com.linkedinfake.core_service.repository.UserRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;

@Component
public class JwtFilter extends OncePerRequestFilter {

	 private static final Logger logger = LoggerFactory.getLogger(JwtFilter.class);

	    private final JwtUtil jwtUtil;
	    private final UserRepository userRepository;

	    public JwtFilter(JwtUtil jwtUtil, UserRepository userRepository) {
	        this.jwtUtil = jwtUtil;
	        this.userRepository = userRepository;
	    }

	    @Override
	    protected void doFilterInternal(HttpServletRequest request,
										HttpServletResponse response,
										FilterChain filterChain) throws ServletException, IOException, IOException {

	        String path = request.getRequestURI();

	        // Pulando endpoints liberados
	        if (path.startsWith("/auth/") || path.equals("/users/register") || path.matches("/users/\\d+/profile")) {
	            filterChain.doFilter(request, response);
	            return;
	        }

	        try {
	            String header = request.getHeader("Authorization");
	            if (header != null && header.startsWith("Bearer ")) {
	                String token = header.substring(7).trim();

	                if (jwtUtil.validateToken(token)) {
	                    Long userId = jwtUtil.getUserIdFromToken(token);

	                    User user = userRepository.findById(userId).orElse(null);
	                    if (user != null) {
	                        // usa DTO simplificado para evitar problemas de LazyLoading
	                        UserPrincipalDTO principalDTO = new UserPrincipalDTO(user);

	                        UsernamePasswordAuthenticationToken auth =
	                            new UsernamePasswordAuthenticationToken(
	                                principalDTO,
	                                null,
	                                Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER"))
	                            );
	                        SecurityContextHolder.getContext().setAuthentication(auth);

	                        logger.debug("Autenticado usuário ID={} via JWT", userId);
	                    }
	                }
	            }

	            filterChain.doFilter(request, response);

	        } catch (Exception ex) {
	            logger.error("Erro no JwtFilter", ex);
	            if (!response.isCommitted()) {
	                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
	                response.setContentType("application/json");
	                response.getWriter().write("{\"error\": \"Unauthorized\"}");
	            }
	        }
	    }
}
