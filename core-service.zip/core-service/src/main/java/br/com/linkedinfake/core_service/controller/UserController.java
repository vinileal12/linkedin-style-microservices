package br.com.linkedinfake.core_service.controller;



import br.com.linkedinfake.core_service.DTOs.user.UserDTO;
import br.com.linkedinfake.core_service.DTOs.user.UserProfileDTO;
import br.com.linkedinfake.core_service.DTOs.user.UserRegisterDTO;
import br.com.linkedinfake.core_service.service.UserService;
import br.com.linkedinfake.core_service.model.Skill;
import br.com.linkedinfake.core_service.model.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

	private final UserService userService;
	private final PasswordEncoder passwordEncoder;


    public UserController(UserService userService , PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/{id}")
    public UserDTO getUser(@PathVariable Long id) {
        return userService.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
    }

    @GetMapping("/available/{id}")
    public List<UserDTO> getAvailableConnections(@PathVariable Long id) {
        return userService.findAvailableConnections(id);
    }
    
    @GetMapping("/{id}/profile")
    public UserProfileDTO getUserProfile(@PathVariable Long id) {
        User user = userService.getUserWithSkills(id)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        return userService.toProfileResponse(user); // retorna DTO limpo
    }
    
    @PostMapping("/register")
    public UserDTO register(@RequestBody UserRegisterDTO request) {
        User user = new User();
        user.setEmail(request.getEmail());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword())); // usa password aqui
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        User saved = userService.save(user);
        return userService.toResponse(saved); // nunca devolve a senha!
    }
    
    @PatchMapping("/{id}/description")
    public User updateDescription(@PathVariable Long id, @RequestBody UserProfileDTO dto) {
        User user = userService.getUserWithSkills(id)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        user.setDescription(dto.getDescription());
        return userService.saveUser(user);
    }
    
    // adicionar skill
    @PostMapping("/{id}/skills")
    public Skill addSkill(@PathVariable Long id, @RequestBody SkillDTO skillDto) {
        return userService.addSkill(id, skillDto.getSkillName());
    }

    // DTO simples para receber a skill do front
    public static class SkillDTO {
        private String skillName;

        public String getSkillName() {
            return skillName;
        }

        public void setSkillName(String skillName) {
            this.skillName = skillName;
        }
    }
	
}
