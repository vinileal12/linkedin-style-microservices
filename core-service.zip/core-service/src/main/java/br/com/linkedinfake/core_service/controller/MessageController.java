package br.com.linkedinfake.core_service.controller;

// Importações necessárias
import br.com.linkedinfake.core_service.DTOs.message.MessageCreateDTO;
import br.com.linkedinfake.core_service.DTOs.message.MessageDTO;
import br.com.linkedinfake.core_service.service.MessageService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/messages") // Rota base para funcionalidades de mensagens
public class MessageController {

    private final MessageService messageService;

    // Injeta o serviço de mensagens
    public MessageController(MessageService messageService) {
        this.messageService = messageService;
    }

    // ==== Enviar uma nova mensagem ====
    @PostMapping
    public ResponseEntity<MessageDTO> sendMessage(@RequestBody MessageCreateDTO dto) {
        return ResponseEntity.ok(messageService.sendMessage(dto));
    }

    // ==== Buscar conversa entre dois usuários ====
    // Ex: GET /messages/conversation?user1=1&user2=2
    @GetMapping("/conversation")
    public ResponseEntity<List<MessageDTO>> getConversation(
            @RequestParam Long user1, // ID do primeiro usuário
            @RequestParam Long user2  // ID do segundo usuário
    ) {
        return ResponseEntity.ok(messageService.getConversation(user1, user2));
    }
}
