package br.com.linkedinfake.core_service.DTOs.post;



import br.com.linkedinfake.core_service.DTOs.comment.CommentDTO;
import lombok.Data;

import java.util.List;

@Data
public class PostResponseDto {
	private Long id;
    private String content;
    private String authorName;
    private String createdAt;
    private List<CommentDTO> comments;
    private Integer degree; // 1 = amigo direto, 2 = amigo do amigo, etc.

}
