package br.com.linkedinfake.core_service.controller;

// Importações necessárias
import br.com.linkedinfake.core_service.DTOs.job.JobCreateDto;
import br.com.linkedinfake.core_service.DTOs.job.JobDto;
import br.com.linkedinfake.core_service.service.JobService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/jobs") // Define a rota base para endpoints relacionados a vagas
public class JobController {

    private final JobService jobService;

    // Injeta o serviço de vagas (JobService)
    public JobController(JobService jobService) {
        this.jobService = jobService;
    }

    // ==== Criar vaga para uma empresa específica ====
    @PostMapping("/company/{companyId}")
    public ResponseEntity<JobDto> createJob(
            @PathVariable Long companyId,     // ID da empresa
            @RequestBody JobCreateDto dto     // Dados da vaga
    ) {
        JobDto job = jobService.createJob(companyId, dto);
        return new ResponseEntity<>(job, HttpStatus.CREATED);
    }

    // ==== Buscar todas as vagas de uma empresa ====
    @GetMapping("/company/{companyId}")
    public ResponseEntity<List<JobDto>> getJobsByCompany(@PathVariable Long companyId) {
        List<JobDto> jobs = jobService.findByCompanyId(companyId);
        return ResponseEntity.ok(jobs);
    }

    // ==== Buscar uma vaga pelo ID ====
    @GetMapping("/{id}")
    public ResponseEntity<JobDto> getJobById(@PathVariable Long id) {
        JobDto job = jobService.getJobById(id);
        return ResponseEntity.ok(job);
    }

    // ==== Buscar todas as vagas disponíveis ====
    @GetMapping
    public ResponseEntity<List<JobDto>> getAllJobs() {
        return ResponseEntity.ok(jobService.findAllJobs());
    }
}
