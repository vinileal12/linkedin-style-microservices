package br.com.linkedinfake.core_service.controller;




import br.com.linkedinfake.core_service.DTOs.post.PostRequestDto;
import br.com.linkedinfake.core_service.DTOs.post.PostResponseDto;
import br.com.linkedinfake.core_service.DTOs.user.UserPrincipalDTO;
import br.com.linkedinfake.core_service.GraphIntegrationService.GraphIntegrationService;
import br.com.linkedinfake.core_service.repository.ConnectionRepository;
import br.com.linkedinfake.core_service.service.PostService;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("/posts")
public class PostController {
	private final PostService postService;
    private final ConnectionRepository connectionRepository;
    private final GraphIntegrationService graphIntegrationService; // <- adicionado

    public PostController(PostService postService,
                          ConnectionRepository connectionRepository,
                          GraphIntegrationService graphIntegrationService) {
        this.postService = postService;
        this.connectionRepository = connectionRepository;
        this.graphIntegrationService = graphIntegrationService;
    }

    @PostMapping
    public PostResponseDto createPost(@RequestBody PostRequestDto request) {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        Long userId;
        if (principal instanceof UserPrincipalDTO user) {
            userId = user.getId();
        } else {
            throw new RuntimeException("Usuário não autenticado");
        }

        return postService.createPost(request, userId);
    }

    @GetMapping("/user/{userId}")
    public List<PostResponseDto> getPostsByUser(@PathVariable Long userId) {
        return postService.getPostsByUserId(userId);
    }

    @GetMapping("/feed")
    public List<PostResponseDto> getFeed() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (!(principal instanceof UserPrincipalDTO user)) {
            throw new RuntimeException("Usuário não autenticado");
        }
        Long userId = user.getId();

        List<Long> friendIds = graphIntegrationService.getFriendsIds(userId);
        friendIds.add(userId);

        return postService.getPostsByUserIds(friendIds, userId);
    }

    
    @GetMapping("/graph/friends/{userId}")
    public List<Long> getFriends(@PathVariable Long userId) {
        return graphIntegrationService.getFriendsIds(userId);
    }
}
