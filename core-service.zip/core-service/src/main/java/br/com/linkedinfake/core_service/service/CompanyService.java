package br.com.linkedinfake.core_service.service;


import br.com.linkedinfake.core_service.DTOs.company.CompanyCreateDTO;
import br.com.linkedinfake.core_service.DTOs.company.CompanyDTO;
import br.com.linkedinfake.core_service.model.Company;
import br.com.linkedinfake.core_service.repository.CompanyRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CompanyService {
	private final CompanyRepository companyRepository;

    public CompanyService(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    public CompanyDTO createCompany(CompanyCreateDTO dto) {
        Company company = new Company();
        company.setName(dto.getName());
        company.setDescription(dto.getDescription());

        Company saved = companyRepository.save(company);

        return mapToDTO(saved);
    }

    public CompanyDTO getCompanyById(Long id) {
        return companyRepository.findById(id)
                .map(this::mapToDTO)
                .orElseThrow(() -> new RuntimeException("Company not found"));
    }

    public List<CompanyDTO> getAllCompanies() {
        return companyRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    private CompanyDTO mapToDTO(Company company) {
        CompanyDTO dto = new CompanyDTO();
        dto.setId(company.getId());
        dto.setName(company.getName());
        dto.setDescription(company.getDescription());
        return dto;
    }
}
