package br.com.linkedinfake.core_service.security;


import br.com.linkedinfake.core_service.jwtUtil.JwtFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class SecurityConfig {
	private final JwtFilter jwtFilter;

    public SecurityConfig(JwtFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf().disable()
            
            // liberação de endpoints
            .authorizeHttpRequests()
            .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll() //  libera preflight CORS
            .requestMatchers("/auth/**", "/users/register", "/users/*/profile").permitAll()
            .requestMatchers("/connections/**").authenticated()
            .requestMatchers("/jobs/**").permitAll()
            .anyRequest().authenticated()
            
            // sessão stateless
            .and()
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            
            // CORS
            .cors().configurationSource(request -> {
                var cors = new org.springframework.web.cors.CorsConfiguration();
                cors.setAllowedOrigins(java.util.List.of("http://localhost:8100"));
                cors.setAllowedMethods(java.util.List.of("GET","POST","PUT","DELETE","PATCH","OPTIONS"));
                cors.setAllowedHeaders(java.util.List.of("Authorization","Content-Type"));
                cors.setAllowCredentials(true);
                return cors;
            })
            
            // JWT
            .and()
            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOrigins("http://localhost:8100")
                        .allowedMethods("GET","POST","PUT","DELETE","PATCH","OPTIONS")
                        .allowCredentials(true);
            }
        };
    }
}
