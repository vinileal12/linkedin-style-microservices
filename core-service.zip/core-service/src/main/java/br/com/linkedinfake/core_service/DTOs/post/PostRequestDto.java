package br.com.linkedinfake.core_service.DTOs.post;

import lombok.Data;

@Data
public class PostRequestDto {
	private Long authorId;
    private String content;
}
