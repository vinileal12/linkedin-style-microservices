package br.com.linkedinfake.core_service.service;


import br.com.linkedinfake.core_service.DTOs.message.MessageCreateDTO;
import br.com.linkedinfake.core_service.DTOs.message.MessageDTO;
import br.com.linkedinfake.core_service.model.Message;
import br.com.linkedinfake.core_service.model.User;
import br.com.linkedinfake.core_service.repository.MessageRepository;
import br.com.linkedinfake.core_service.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MessageService {
	 private final MessageRepository messageRepository;
	    private final UserRepository userRepository;

	    public MessageService(MessageRepository messageRepository, UserRepository userRepository) {
	        this.messageRepository = messageRepository;
	        this.userRepository = userRepository;
	    }

	    public MessageDTO sendMessage(MessageCreateDTO dto) {
	        User sender = userRepository.findById(dto.getSenderId())
	                .orElseThrow(() -> new RuntimeException("Sender not found"));
	        User receiver = userRepository.findById(dto.getReceiverId())
	                .orElseThrow(() -> new RuntimeException("Receiver not found"));

	        Message message = Message.builder()
	                .sender(sender)
	                .receiver(receiver)
	                .body(dto.getBody())       // ou dto.getContent() dependendo do DTO
	                .createdAt(LocalDateTime.now())  // ✅ campo correto
	                .build();


	        Message saved = messageRepository.save(message);

	        return toDTO(saved);
	    }

	    public List<MessageDTO> getConversation(Long userId1, Long userId2) {
	        return messageRepository
	                .findBySenderIdAndReceiverIdOrSenderIdAndReceiverIdOrderByCreatedAtAsc(
	                        userId1, userId2, userId2, userId1
	                )
	                .stream()
	                .map(this::toDTO)
	                .collect(Collectors.toList());
	    }

	    private MessageDTO toDTO(Message message) {
	        MessageDTO dto = new MessageDTO();
	        dto.setId(message.getId());
	        dto.setSenderId(message.getSender().getId());
	        dto.setSenderName(message.getSender().getFirstName() + " " + message.getSender().getLastName());
	        dto.setReceiverId(message.getReceiver().getId());
	        dto.setReceiverName(message.getReceiver().getFirstName() + " " + message.getReceiver().getLastName());
	        dto.setBody(message.getBody());
	        dto.setSentAt(message.getCreatedAt());
	        return dto;
	    }
}
