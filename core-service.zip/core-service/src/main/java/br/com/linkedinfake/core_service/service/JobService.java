package br.com.linkedinfake.core_service.service;


import br.com.linkedinfake.core_service.DTOs.job.JobCreateDto;
import br.com.linkedinfake.core_service.DTOs.job.JobDto;
import br.com.linkedinfake.core_service.model.Company;
import br.com.linkedinfake.core_service.model.Job;
import br.com.linkedinfake.core_service.repository.CompanyRepository;
import br.com.linkedinfake.core_service.repository.JobRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class JobService {
	private final JobRepository jobRepository;
    private final CompanyRepository companyRepository;

    public JobService(JobRepository jobRepository, CompanyRepository companyRepository) {
        this.jobRepository = jobRepository;
        this.companyRepository = companyRepository;
    }

    public JobDto createJob(Long companyId, JobCreateDto dto) {
        Company company = companyRepository.findById(companyId)
                .orElseThrow(() -> new RuntimeException("Company not found"));

        Job job = new Job();
        job.setTitle(dto.getTitle());
        job.setDescription(dto.getDescription());
        job.setCompany(company);

        Job saved = jobRepository.save(job);

        return mapToDto(saved);
    }

    public List<JobDto> findByCompanyId(Long companyId) {
        return jobRepository.findByCompanyId(companyId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    public JobDto getJobById(Long id) {
        return jobRepository.findById(id)
                .map(this::mapToDto)
                .orElseThrow(() -> new RuntimeException("Job not found"));
    }

    private JobDto mapToDto(Job job) {
        JobDto dto = new JobDto();
        dto.setId(job.getId());
        dto.setTitle(job.getTitle());
        dto.setDescription(job.getDescription());
        dto.setCompanyId(job.getCompany().getId());
        dto.setCompanyName(job.getCompany().getName()); // <- adiciona isso
        dto.setCreatedAt(job.getCreatedAt().toString()); // opcional, se quiser preencher createdAt
        return dto;

    }
    
    public List<JobDto> findAllJobs() {
        return jobRepository.findAll()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }
}
