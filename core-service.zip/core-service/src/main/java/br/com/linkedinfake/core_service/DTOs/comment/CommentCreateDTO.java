package br.com.linkedinfake.core_service.DTOs.comment;

import lombok.Data;

@Data
public class CommentCreateDTO {
	
	private Long authorId;
    private String content;

}
