package br.com.linkedinfake.core_service.DTOs.job;

import lombok.Data;

@Data
public class JobDto {
	private Long id;
    private String title;
    private String description;
    private String companyName;
    private String createdAt;
    private Long companyId;
}
