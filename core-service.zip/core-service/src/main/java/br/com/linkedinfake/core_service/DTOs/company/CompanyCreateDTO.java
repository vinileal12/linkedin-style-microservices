package br.com.linkedinfake.core_service.DTOs.company;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor @NoArgsConstructor
public class CompanyCreateDTO {
	private String name;
    private String description;
}
