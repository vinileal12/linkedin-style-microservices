package br.com.linkedinfake.core_service.GraphIntegrationService;


import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class GraphIntegrationService {
	
	private final RestTemplate restTemplate;
    private final String neo4jBaseUrl = "http://localhost:8082"; // microserviço Neo4j

    public GraphIntegrationService() {
        this.restTemplate = new RestTemplate();
    }

    public void createConnection(Long userId, Long friendId) {
        String url = neo4jBaseUrl + "/graph/users/" + userId + "/connect/" + friendId;
        restTemplate.postForObject(url, null, Void.class);
    }

    // novo método para buscar IDs dos amigos
    public List<Long> getFriendsIds(Long userId) {
        String url = neo4jBaseUrl + "/graph/users/" + userId + "/friends";
        // retorna lista de Long
        return restTemplate.getForObject(url, List.class);
    }
    
    public Integer getFriendDegree(Long userId, Long otherUserId) {
        String url = neo4jBaseUrl + "/graph/users/" + userId + "/degree/" + otherUserId;
        return restTemplate.getForObject(url, Integer.class);
    }

}
