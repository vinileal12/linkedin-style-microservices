package br.com.linkedinfake.core_service.DTOs.post;

import lombok.Data;

@Data
public class PostCreateDTO {
	private Long authorId; // corresponde ao 'author' na entidade
    private String content;
}
