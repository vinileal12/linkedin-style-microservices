package br.com.linkedinfake.core_service.service;





import br.com.linkedinfake.core_service.DTOs.application.ApplicationDto;
import br.com.linkedinfake.core_service.model.Application;
import br.com.linkedinfake.core_service.model.Job;
import br.com.linkedinfake.core_service.model.User;
import br.com.linkedinfake.core_service.repository.ApplicationRepository;
import br.com.linkedinfake.core_service.repository.JobRepository;
import br.com.linkedinfake.core_service.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ApplicationService {
	private final ApplicationRepository applicationRepository;
    private final UserRepository userRepository;
    private final JobRepository jobRepository;

    public ApplicationService(ApplicationRepository applicationRepository,
                              UserRepository userRepository,
                              JobRepository jobRepository) {
        this.applicationRepository = applicationRepository;
        this.userRepository = userRepository;
        this.jobRepository = jobRepository;
    }

    public ApplicationDto apply(Long userId, Long jobId) {
        Optional<User> userOpt = userRepository.findById(userId);
        Optional<Job> jobOpt = jobRepository.findById(jobId);

        if (userOpt.isEmpty()) {
            throw new RuntimeException("User not found");
        }
        if (jobOpt.isEmpty()) {
            throw new RuntimeException("Job not found");
        }

        Application application = new Application();
        application.setUser(userOpt.get());
        application.setJob(jobOpt.get());

        Application saved = applicationRepository.save(application);

        return new ApplicationDto(
                saved.getId(),
                saved.getUser().getId(),
                saved.getJob().getId(),
                saved.getAppliedAt().toString()
        );
    }
}
